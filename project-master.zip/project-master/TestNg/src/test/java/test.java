import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Created by LiXuan on 2017/6/19.
 */
public class test {
   @Test()
    public void testmethod1(){
       Assert.assertEquals(1,1);
   }
}
